README:

Edit parameters near the bottom to change temperature, alpha, source file etc

Edit filename to run a different test

Outputs information from each temperature iteration, and what the initial solution and best solution are
