README:

Conga game, just run normally without any paramters. Will output information on final board state and winner/loser